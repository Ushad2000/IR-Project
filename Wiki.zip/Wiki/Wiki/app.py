from flask import Flask, request, jsonify, render_template
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle
import os
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import string

app = Flask(__name__)

# Download NLTK resources (run only once)
nltk.download('punkt')
nltk.download('stopwords')

# Load TF-IDF vectorizer and cosine similarity matrix
with open("tfidf_vectorizer.pickle", "rb") as handle:
    vectorizer = pickle.load(handle)

with open("cosine_similarity_matrix.pickle", "rb") as handle:
    cosine_sim_matrix = pickle.load(handle)

# Path to the folder containing HTML documents
documents_folder = "output"

# Function to load documents from the folder
def load_documents(folder_path):
    documents = []
    filenames = os.listdir(folder_path)
    for filename in filenames:
        with open(os.path.join(folder_path, filename), "r", encoding="utf-8") as file:
            document = file.read()
            documents.append(document)
    return documents

# Load documents
documents = load_documents(documents_folder)

# Preprocess text
def preprocess_text(text):
    # Tokenization
    tokens = word_tokenize(text.lower())
    # Remove punctuation
    tokens = [word for word in tokens if word.isalnum()]
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]
    return ' '.join(tokens)

def get_url_for_filename(filename):
    # Remove the 'quotes-' prefix and '.html' suffix to get the page name
    page_name = filename.replace('quotes-', '').replace('.html', '')
    
    # Define a dictionary to map each page name to its corresponding URL
    page_urls = {
        "Flask_(web_framework)": "https://en.wikipedia.org/wiki/Flask_(web_framework)",
        "Scikit-learn": "https://en.wikipedia.org/wiki/Scikit-learn",
        "Scrape": "https://en.wikipedia.org/wiki/Scrape"
    }

    # Return the URL corresponding to the page name
    return page_urls.get(page_name, "")

# Route for rendering the index page
@app.route('/')
def index():
    return render_template('index.html')

# Route for processing queries
@app.route('/search', methods=['POST'])
def search():
    query = request.json.get('query')
    top_k = int(request.json.get('top_k', 5))

    # Preprocess query
    processed_query = preprocess_text(query)

    # Vectorize query
    query_vector = vectorizer.transform([processed_query])

    # Calculate cosine similarity between query and documents
    cosine_similarities = cosine_similarity(query_vector, vectorizer.transform(documents))

    # Get top-K similar documents
    top_indices = cosine_similarities.argsort()[0][-top_k:][::-1]
    



    # Construct response
    results = []
    for idx in top_indices:
        filename = os.listdir(documents_folder)[idx]
        url = get_url_for_filename(filename)  # You need to define a function to get the URL for the filename
        results.append({
            'filename': filename,
            'url': str(url),
            'cosine_similarity': cosine_sim_matrix[idx][0]
        })
    
    # Return JSON response with the search results
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
