from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os
import pickle

# Path to the folder containing HTML documents
documents_folder = "output"

# Function to load documents from the folder
def load_documents(folder_path):
    documents = []
    filenames = os.listdir(folder_path)
    for filename in filenames:
        with open(os.path.join(folder_path, filename), "r", encoding="utf-8") as file:
            document = file.read()
            documents.append(document)
    return documents

# Load documents
documents = load_documents(documents_folder)

# TF-IDF Vectorization
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(documents)

# Calculate cosine similarity matrix
cosine_sim_matrix = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Save TF-IDF vectorizer and cosine similarity matrix
with open("tfidf_vectorizer.pickle", "wb") as handle:
    pickle.dump(vectorizer, handle)

with open("cosine_similarity_matrix.pickle", "wb") as handle:
    pickle.dump(cosine_sim_matrix, handle)
