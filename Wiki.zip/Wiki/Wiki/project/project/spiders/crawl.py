import scrapy
from pathlib import Path


class CrawlSpider(scrapy.Spider):
    name = "crawl"
    allowed_domains = ["wikipedia.org"]
    start_urls = ["https://wikipedia.org"]
    
    # Initialize seed URL/Domain, Max Pages, and Max Depth
    def __init__(self, seed_url=None, max_pages=10, max_depth=3, *args, **kwargs):
        super(CrawlSpider, self).__init__(*args, **kwargs)
        self.start_urls = [seed_url] if seed_url else ["https://wikipedia.org"]
        self.max_pages = max_pages
        self.max_depth = max_depth

    def start_requests(self):
        urls = [
            "https://en.wikipedia.org/wiki/Scrape",
            "https://en.wikipedia.org/wiki/Flask_(web_framework)",
            "https://en.wikipedia.org/wiki/Scikit-learn",
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse, meta={'depth': 0})

    def parse(self, response):
        page = response.url.split("/")[-2] if response.url.endswith('/') else response.url.split("/")[-1]
        filename = f"quotes-{page}.html"
        Path(filename).write_bytes(response.body)
        self.log(f"Saved file {filename}")

        # Extract links and follow recursively up to max depth
        if response.meta['depth'] < self.max_depth:
            links = response.css('a::attr(href)').extract()
            for link in links:
                yield response.follow(link, callback=self.parse, meta={'depth': response.meta['depth'] + 1})

        # Control max pages
        if self.max_pages > 0:
            self.max_pages -= 1
            if self.max_pages == 0:
                self.crawler.engine.close_spider(self, 'Reached max pages limit')
