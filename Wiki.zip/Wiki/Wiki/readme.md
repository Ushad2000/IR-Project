# Project Report(Usha Devaraju - A20539949)

## Abstract
The project aims to develop a web crawling, indexing, and querying system using Scrapy, Scikit-Learn, and Flask.

## Overview
The system consists of three main components: a web crawler for downloading web documents, an indexer for constructing an inverted index, and a processor for handling user queries.

## Design
Each component is designed to fulfill specific functionalities, such as content crawling, search indexing, and query processing.

## Architecture
The architecture comprises software components for crawling, indexing, and querying. These components interact to provide a seamless user experience.

## Operation
To run the project:
1. Create a virtual environment:
        python -m venv venv

2. Activate the virtual environment:
- On Windows:
  ```
  venv\Scripts\activate
  ```
- On macOS and Linux:
  ```
  source venv/bin/activate
  ```

3. Install dependencies from requirements.txt:
        pip install -r requirements.txt
        Go to the Wiki folder where requirements.txt is present


4. For crawling:
- Navigate to the project directory:
  ```
  cd project
  cd project
  cd spiders
  ```
- Run the Scrapy crawler:
  ```
  scrapy crawl crawl
  ```

5. For indexing:
- Run the indexer script:
  ```

  Go to the Wiki folder where indexer.py file is available
  python indexer.py
  ```

6. For running the Flask app:
        Go to the Wiki folder where app.py file is available
        python app.py


## Conclusion
The project demonstrates successful implementation of web crawling, indexing, and querying functionalities. Further improvements could include enhancing query processing capabilities and scalability.

## Data Sources
The project utilizes data from Wikipedia, specifically:
- [Scrape](https://en.wikipedia.org/wiki/Scrape)
- [Flask (web framework)](https://en.wikipedia.org/wiki/Flask_(web_framework))
- [Scikit-learn](https://en.wikipedia.org/wiki/Scikit-learn)

## Test Cases
The project includes unit tests to ensure the functionality of the components, covering framework, harness, and coverage.

## Source Code
The source code listings are provided for each component, along with documentation and dependencies.

## Bibliography
- Kamath, S., & Ananthanarayana, V. S. (2014, December). A service crawler framework for similarity based web service discovery. In 2014 Annual IEEE India Conference (INDICON) (pp. 1-6). IEEE.
- Xie, D. X., & Xia, W. F. (2014). Design and implementation of the topic-focused crawler based on scrapy. Advanced materials research, 850, 487-490.
- Gaspar, D., & Stouffer, J. (2018). Mastering Flask Web Development: Build Enterprise-grade, Scalable Python Web Applications. Packt Publishing Ltd.
