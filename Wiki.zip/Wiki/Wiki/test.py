import unittest
import json
from app import app

class TestApp(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_index_page(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)

    def test_search_with_valid_query(self):
        query_data = {'query': 'test query', 'top_k': 5}
        response = self.app.post('/search', json=query_data)
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(isinstance(data, list))
        self.assertTrue(len(data) > 0)
        for result in data:
            self.assertIn('filename', result)
            self.assertIn('url', result)
            self.assertIn('cosine_similarity', result)

if __name__ == '__main__':
    unittest.main()
